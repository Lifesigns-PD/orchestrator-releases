#!/bin/bash

# Define variables
SERVICE_NAME="go-ble-orchestrator"
INSTALL_DIR="/opt/go-ble-orchestrator"
SERVICE_FILE="/etc/systemd/system/${SERVICE_NAME}.service"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
  echo "Please run as root"
  exit 1
fi

echo "Uninstalling ${SERVICE_NAME}..."

# Stop and disable service
if systemctl is-active --quiet ${SERVICE_NAME}; then
    echo "Stopping service..."
    systemctl stop ${SERVICE_NAME}
fi

if systemctl is-enabled --quiet ${SERVICE_NAME}; then
    echo "Disabling service..."
    systemctl disable ${SERVICE_NAME}
fi

# Remove service file
if [ -f "${SERVICE_FILE}" ]; then
    echo "Removing service file..."
    rm ${SERVICE_FILE}
    systemctl daemon-reload
fi

# Remove installation directory
if [ -d "${INSTALL_DIR}" ]; then
    echo "Removing installation directory..."
    rm -rf ${INSTALL_DIR}
fi

echo "${SERVICE_NAME} uninstalled successfully."
