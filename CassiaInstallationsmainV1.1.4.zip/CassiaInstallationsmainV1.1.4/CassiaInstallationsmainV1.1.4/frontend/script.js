document.addEventListener('DOMContentLoaded', () => {
    // --- DOM Element References ---
    const mainContent = document.getElementById('mainContent');
    const loginModal = document.getElementById('loginModal');
    const loginButton = document.getElementById('loginButton');
    const passwordInput = document.getElementById('password');
    const loginError = document.getElementById('loginError');
    const logoutButton = document.getElementById('logoutButton');

    const statusMessage = document.getElementById('statusMessage');
    const devicesTabBtn = document.getElementById('devicesTabBtn');
    const logsTabBtn = document.getElementById('logsTabBtn');
    const configTabBtn = document.getElementById('configTabBtn');
    const devicesPage = document.getElementById('devicesPage');
    const logsPage = document.getElementById('logsPage');
    const configPage = document.getElementById('configPage');
    
    // Sub-Tab Elements
    const activeDevicesTabBtn = document.getElementById('activeDevicesTabBtn');
    const inactiveDevicesTabBtn = document.getElementById('inactiveDevicesTabBtn');
    const activeDevicesPage = document.getElementById('activeDevicesPage');
    const inactiveDevicesPage = document.getElementById('inactiveDevicesPage');

    const configureButton = document.getElementById('configureButton');
    const startButton = document.getElementById('startButton');
    const stopButton = document.getElementById('stopButton');
    const acDomainInput = document.getElementById('acDomainInput');
    const jsonNotifyEndpointInput = document.getElementById('jsonNotifyEndpointInput');
    const devicePrefixesInput = document.getElementById('devicePrefixes');
    const inactivityRulesInput = document.getElementById('inactivityRules');
    const connectedList = document.getElementById('connectedList');
    const blacklistedList = document.getElementById('blacklistedList');
    const apList = document.getElementById('apList');
    const logList = document.getElementById('logList');
    const rejectedList = document.getElementById('rejectedList');

    let pollingInterval;

    // --- Tab Navigation ---
    function showPage(pageName) {
        devicesPage.style.display = 'none';
        logsPage.style.display = 'none';
        configPage.style.display = 'none';

        devicesTabBtn.classList.remove('active');
        logsTabBtn.classList.remove('active');
        configTabBtn.classList.remove('active');

        if (pageName === 'devices') {
            devicesPage.style.display = 'block';
            devicesTabBtn.classList.add('active');
        } else if (pageName === 'logs') {
            logsPage.style.display = 'block';
            logsTabBtn.classList.add('active');
        } else if (pageName === 'config') {
            configPage.style.display = 'block';
            configTabBtn.classList.add('active');
            fetchAndDisplayConfig();
        }
        fetchAllLists();
    }

    // --- Sub-Tab Navigation ---
    function showSubPage(subPageName) {
        activeDevicesPage.style.display = 'none';
        inactiveDevicesPage.style.display = 'none';
        activeDevicesTabBtn.classList.remove('active');
        inactiveDevicesTabBtn.classList.remove('active');

        if (subPageName === 'active') {
            activeDevicesPage.style.display = 'block';
            activeDevicesTabBtn.classList.add('active');
        } else if (subPageName === 'inactive') {
            inactiveDevicesPage.style.display = 'block';
            inactiveDevicesTabBtn.classList.add('active');
        }
    }
    
    activeDevicesTabBtn.addEventListener('click', () => showSubPage('active'));
    inactiveDevicesTabBtn.addEventListener('click', () => showSubPage('inactive'));

    // --- Tab clicks no longer need security checks ---
    devicesTabBtn.addEventListener('click', () => showPage('devices'));
    logsTabBtn.addEventListener('click', () => showPage('logs'));
    configTabBtn.addEventListener('click', () => showPage('config'));
    
    // --- Login & Logout ---
    function handleLogin() {
        if (passwordInput.value === 'Life@2024') {
            loginModal.style.display = 'none';
            mainContent.style.display = 'block';
            loginError.textContent = '';
            passwordInput.value = '';

            // --- Initial Setup & Polling on Login ---
            showPage('devices');
            showSubPage('active');
            fetchAllLists();
            if (pollingInterval) clearInterval(pollingInterval);
            pollingInterval = setInterval(fetchAllLists, 3000);

        } else {
            loginError.textContent = 'Invalid password.';
            passwordInput.value = '';
        }
    }

    function handleLogout() {
        if (pollingInterval) clearInterval(pollingInterval);
        mainContent.style.display = 'none';
        loginModal.style.display = 'flex';
        
        // Clear lists to prevent flash of old data on next login
        connectedList.innerHTML = '';
        blacklistedList.innerHTML = '';
        rejectedList.innerHTML = '';
        logList.innerHTML = '';
        apList.innerHTML = '';
    }
    
    loginButton.addEventListener('click', handleLogin);
    logoutButton.addEventListener('click', handleLogout);
    passwordInput.addEventListener('keyup', (event) => {
        if (event.key === 'Enter') {
            handleLogin();
        }
    });

    // --- REWRITTEN: Update Connected List with Final UI Changes ---
    function updateConnectedList(devices) {
        connectedList.innerHTML = ''; 
        if (devices && devices.length > 0) {
            devices.sort((a, b) => (a.serial_number || a.mac).localeCompare(b.serial_number || b.mac));
            
            devices.forEach(device => {
                const tile = document.createElement('div');
                tile.className = 'device-tile';

                const displayID = device.name || device.serial_number //|| device.mac;
                const battery = device.battery ? `${device.battery}%` : 'N/A';
                
                const packetWarningClass = (device.packets_received === 0 && device.packets_sent === 0) ? 'warning-text' : '';
                const rssiWarningClass = device.avg_rssi === 0 ? 'warning-text' : '';

                tile.innerHTML = `
                    <div class="tile-header">
                        <div class="tile-id-block">
                            <strong>${displayID}</strong>
                            <small>${device.name}</small>
                        </div>
                        <div class="tile-ap-block info-block">
                           <span>On AP</span>
                           <strong>${device.ap}</strong>
                        </div>
                    </div>

                    <div class="packet-counter">
                        <span>Packets Received / Sent</span>
                        <strong class="${packetWarningClass}">${device.packets_received} / ${device.packets_sent}</strong>
                    </div>

                    <div class="tile-body">
                        <div class="info-block">
                            <span>Avg. RSSI</span>
                            <strong class="${rssiWarningClass}">${device.avg_rssi.toFixed(2)} dBm</strong>
                        </div>
                        <div class="info-block">
                            <span>Battery</span>
                            <strong>${battery}</strong>
                        </div>
                    </div>
                    
                    <div class="tile-footer">
                        <button class="reconnect-btn" data-mac="${device.mac}">Reconnect</button>
                        <button class="blacklist-btn" data-mac="${device.mac}" data-name="${device.name}">Blacklist</button>
                    </div>`;

                connectedList.appendChild(tile);
            });
        } else {
            connectedList.innerHTML = '<p style="text-align: center; color: #6c757d;">No connected devices.</p>';
        }
        addDeviceActionListeners(connectedList);
    }
    
    // --- Other UI Update Functions ---
    function updateBlacklistedList(devices) {
        blacklistedList.innerHTML = '';
        if (devices && devices.length > 0) {
            devices.sort((a, b) => (a.name || 'N/A').localeCompare(b.name || 'N/A'));
            devices.forEach(device => {
                const li = document.createElement('li');
                const displayName = device.serial_number || device.name || 'N/A';
                li.innerHTML = `
                    <div class="device-info">
                        <strong>${displayName} (${device.mac})</strong>
                        <small>Blacklisted at: ${new Date(device.blacklistedAt).toLocaleString()}</small>
                    </div>
                    <div class="action-buttons">
                        <button class="unblacklist-btn" data-mac="${device.mac}">Unblacklist</button>
                    </div>`;
                blacklistedList.appendChild(li);
            });
        } else {
            blacklistedList.innerHTML = '<li>No blacklisted devices.</li>';
        }
        addDeviceActionListeners(blacklistedList);
    }

    function updateRejectedList(devices) {
        rejectedList.innerHTML = '';
        if (devices && devices.length > 0) {
            devices.sort((a, b) => new Date(b.rejectedAt) - new Date(a.rejectedAt));
            devices.forEach(device => {
                const li = document.createElement('li');
                const rejectionTime = new Date(device.rejectedAt).toLocaleString();
                li.innerHTML = `
                    <div class="device-info">
                        <strong>${device.name} (${device.mac})</strong>
                        <small>Rejected on AP <strong>${device.ap}</strong> at ${rejectionTime}</small>
                        <small>Reason: ${device.reason} (RSSI: ${device.rssi} dBm)</small>
                    </div>`;
                rejectedList.appendChild(li);
            });
        } else {
            rejectedList.innerHTML = '<li>No devices have been rejected for low signal.</li>';
        }
    }
    
    function updateConnectionLogsList(logs) {
        logList.innerHTML = ''; 
        if (logs && logs.length > 0) {
            logs.reverse();
            logs.forEach(log => {
                const li = document.createElement('li');
                const logTime = new Date(log.timestamp).toLocaleString();
                let logHTML = `<div class="device-info">
                                <small>${logTime} - [${log.status.toUpperCase()}] Device ${log.mac} (${log.deviceName || 'N/A'}) on AP ${log.ap}</small>`;
                if (log.status === 'stalled_disconnecting') {
                    const battery = log.battery ? `${log.battery}%` : 'N/A';
                    logHTML += `<small style="margin-left: 15px;">&mdash; State at stall: Pkts Rcvd: ${log.packets_received || 0}, Pkts Sent: ${log.packets_sent || 0}, Battery: ${battery}, Avg RSSI: ${log.avg_rssi ? log.avg_rssi.toFixed(2) : 'N/A'}</small>`;
                }
                logHTML += `</div>`;
                li.innerHTML = logHTML;
                logList.appendChild(li);
            });
        } else {
            logList.innerHTML = '<li>No connection logs available.</li>'; 
        }
    }

    function updateAPList(aps) {
        apList.innerHTML = '';
        if (aps && aps.length > 0) {
            aps.forEach(ap => {
                const li = document.createElement('li');
                li.innerHTML = `<div class="device-info"><strong>${ap.mac}</strong><small>Status: ${ap.status} | IP: ${ap.localip || 'N/A'}</small></div>`;
                apList.appendChild(li);
            });
        } else {
            apList.innerHTML = '<li>No active APs found.</li>';
        }
    }

    // --- Action Listeners & API Calls ---
    function addDeviceActionListeners(ulElement) {
        ulElement.querySelectorAll('button').forEach(button => {
            button.onclick = (e) => {
                const mac = e.currentTarget.dataset.mac;
                const name = e.currentTarget.dataset.name;
                const classList = e.currentTarget.classList;

                if (classList.contains('unblacklist-btn')) {
                    unblacklistDevice(mac);
                } else if (classList.contains('blacklist-btn')) {
                    disconnectDevice(mac, true, name);
                } else if (classList.contains('reconnect-btn')) {
                    disconnectDevice(mac, false);
                }
            };
        });
    }

    async function apiPost(endpoint, body) {
        try {
            const response = await fetch(endpoint, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body)
            });
            const result = await response.json();
            statusMessage.textContent = result.message;
            statusMessage.style.color = response.ok ? 'green' : 'red';
            fetchAllLists();
        } catch (error) {
            statusMessage.textContent = 'Network error or server unreachable.';
            statusMessage.style.color = 'red';
        }
    }

    function disconnectDevice(mac, shouldBlacklist, deviceName = '') {
        const endpoint = shouldBlacklist ? '/api/disconnect-device' : '/api/disconnect-device-only';
        apiPost(endpoint, { mac, deviceName });
    }

    function unblacklistDevice(mac) {
        apiPost('/api/unblacklist-device', { mac });
    }

    // --- Data Fetching ---
    async function fetchData(url) {
        try {
            const response = await fetch(url);
            if (response.status === 503) { return { error: 'services-down', data: [] }; }
            if (!response.ok) { return { error: 'fetch-failed', data: [] }; }
            return { error: null, data: await response.json() };
        } catch (e) {
            return { error: 'network-error', data: [] };
        }
    }

    async function fetchAllLists() {
        if (devicesPage.style.display !== 'none') {
            const { data: connected } = await fetchData('/api/connected-devices');
            updateConnectedList(connected);
            const { data: blacklisted } = await fetchData('/api/blacklisted-devices');
            updateBlacklistedList(blacklisted);
            const { data: rejected } = await fetchData('/api/rejected-connections');
            updateRejectedList(rejected);            
        }
        if (configPage.style.display !== 'none') {
            const { data: aps } = await fetchData('/api/get-aps');
            updateAPList(aps);
        }
        if (logsPage.style.display !== 'none') {
            const { data: logs } = await fetchData('/api/connection-logs');
            updateConnectionLogsList(logs);
        }
    }
    
    // --- Config Functions ---
    async function fetchAndDisplayConfig() {
        try {
            const response = await fetch('/api/get-config');
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
            const config = await response.json();
            document.getElementById('currentACDomain').textContent = config.acDomain || 'N/A';
            acDomainInput.value = config.acDomain || '';
            jsonNotifyEndpointInput.value = config.jsonNotifyEndpoint || '';
        } catch (error) {
            document.getElementById('currentACDomain').textContent = 'Error loading config.';
        }
    }
    
    configureButton.addEventListener('click', () => {
        const payload = {
            acDomain: acDomainInput.value,
            jsonEndpoint: jsonNotifyEndpointInput.value,
            devicePrefixes: devicePrefixesInput.value,
            inactivityRules: inactivityRulesInput.value,
        };
        apiPost('/api/config', payload);
    });

    startButton.addEventListener('click', () => apiPost('/api/start-services', {}));
    stopButton.addEventListener('click', () => apiPost('/api/stop-services', {}));
});