# BLE Orchestrator V1.1.3 - Release Notes

## Version: 1.1.3
**Release Date:** 2026-01-12  
**Target Platform:** Linux AMD64

---

## Critical Fixes & Enhancements

### 🚀 **Worker Pool Capacity Upgrade**
- Buffer size: 500 → 1,000 per partition (+100%)
- Total capacity: 200,000 → 400,000 packets
- Warning threshold: 450 → 750 (75% capacity)
- **Impact:** Eliminates queue saturation under heavy load

### 📡 **RSSI Threshold Adjustment**
- Minimum signal: -100 dBm → -85 dBm
- **Impact:** Only connects devices with reliable signal strength

### 🎯 **STRICT 125-Sample ECG Enforcement**
- **Guaranteed:** EXACTLY 125 samples per JSON POST
- **Guaranteed:** EXACTLY 1 POST per second
- Overflow protection with buffer carryover (no data loss)
- **Impact:** Consistent, predictable ECG data streaming

---

## Deployment

### Files Included:
- `go-ble-orchestrator` (Linux binary)
- `config.json` (configuration template)
- `CassiaAC_Install.sh` (AC installation script)
- `DeviceManager_Install.sh` (service installation)
- `frontend/` (dashboard UI)
- `README.md` (deployment instructions)

### Installation:
```bash
cd CassiaInstallationsMainV1.1.3
chmod +x *.sh
sudo ./DeviceManager_Install.sh
```

---

## Upgrade from V1.1.2

**Breaking Changes:** None  
**Config Changes:** None required

**Simple Upgrade:**
```bash
sudo systemctl stop go-ble-orchestrator
sudo cp go-ble-orchestrator /opt/go-ble-orchestrator/
sudo systemctl start go-ble-orchestrator
```

---

## Verification

After deployment, monitor for:
- ✅ Queue depth warnings should disappear
- ✅ Every JSON should have exactly 125 ECG samples
- ✅ Evaluation time < 1 second
- ✅ No "BUFFER OVERFLOW" warnings (under normal load)

---

**Built for production stability and reliable ECG data streaming.**
