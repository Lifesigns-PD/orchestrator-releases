#!/bin/bash

# This script automates the installation of the Cassia AC software on a fresh Ubuntu system.
# It includes prerequisite checks, cleanup of old versions, and deployment.
# It must be run with sudo privileges.

# Exit immediately if a command exits with a non-zero status.
set -e

# --- Helper function for logging ---
log() {
    echo "--- $1 ---"
}

# --- Check for sudo privileges ---
if [ "$EUID" -ne 0 ]; then
  log "ERROR: Please run this script with sudo."
  exit 1
fi

# --- Get the original user who ran sudo ---
ORIGINAL_USER=${SUDO_USER:-$USER}

# --- Prerequisite: Check Ubuntu Version ---
log "Verifying Ubuntu version..."
REQUIRED_VERSION="22.04"
CURRENT_VERSION=$(lsb_release -rs)

if ! dpkg --compare-versions "$CURRENT_VERSION" "ge" "$REQUIRED_VERSION"; then
    log "ERROR: This script requires Ubuntu version $REQUIRED_VERSION or higher."
    log "Your version is $CURRENT_VERSION. Please upgrade your system before running this script."
    exit 1
else
    log "Ubuntu version $CURRENT_VERSION is compatible."
fi
echo

# --- Step 1: Install SSH Server (if not present) ---
log "Checking for SSH Server..."
if ! dpkg -l | grep -q openssh-server; then
    log "SSH server not found. Installing..."
    apt-get update
    apt-get install -y openssh-server
else
    log "SSH server is already installed."
fi
echo

# --- Step 2: Uninstall Old Docker Versions ---
log "Uninstalling any old Docker versions..."
for pkg in docker.io docker-doc docker-compose podman-docker containerd runc; do
    apt-get remove -y $pkg > /dev/null 2>&1 || true
done
log "Finished uninstalling old versions."
echo

# --- Step 3: Install Docker (if not present) ---
log "Checking for Docker..."
if ! command -v docker &> /dev/null; then
    log "Docker not found. Installing..."
    apt-get update
    apt-get install -y ca-certificates curl
    install -m 0755 -d /etc/apt/keyrings
    curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
    chmod a+r /etc/apt/keyrings/docker.asc
    echo \
      "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu \
      $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | \
      tee /etc/apt/sources.list.d/docker.list > /dev/null
    apt-get update
    apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
    log "Docker installed successfully."
else
    log "Docker is already installed."
fi
echo

# --- Step 4: Configure Docker Post-Installation ---
USER_WAS_ADDED=false
log "Adding user '$ORIGINAL_USER' to the 'docker' group..."
if ! getent group docker | grep -q "\b$ORIGINAL_USER\b"; then
    usermod -aG docker "$ORIGINAL_USER"
    log "User added to docker group."
    USER_WAS_ADDED=true
else
    log "User '$ORIGINAL_USER' is already in the 'docker' group."
fi
echo

# --- Check if Docker is running ---
log "Checking if Docker daemon is running..."
if ! docker info > /dev/null 2>&1; then
    log "ERROR: Docker daemon is not running. Please start Docker and re-run this script."
    exit 1
fi
log "Docker daemon is running."
echo

# --- Step 5: Deploy the Cassia AC Software ---
AC_DEPLOY_SCRIPT_URL="http://www.bluetooth.tech/acDeploy64.sh"
AC_DEPLOY_SCRIPT_NAME="acDeploy64.sh"

log "Attempting to stop and remove any existing Cassia AC container..."
su - "$ORIGINAL_USER" -c "docker stop ac64" || true
su - "$ORIGINAL_USER" -c "docker rm ac64" || true
log "Cleanup complete."
echo

log "Pulling the Cassia AC updater image from Docker Hub..."
su - "$ORIGINAL_USER" -c "docker pull cassia/updater64"

log "Downloading the Cassia AC deployment script..."
wget -q -O "$AC_DEPLOY_SCRIPT_NAME" "$AC_DEPLOY_SCRIPT_URL"

log "Running the deployment script..."
sh "$AC_DEPLOY_SCRIPT_NAME"

log "Verifying that the container is running..."
su - "$ORIGINAL_USER" -c "docker ps"
echo

# --- Final Instructions ---
log "✅ Automated installation steps are complete!"
SERVER_IP=$(hostname -I | awk '{print $1}')
log "Please follow the remaining manual steps:"
echo "1. Download the AC Server firmware from Cassia's support website."
echo "   - URL: https://www.cassianetworks.com/support/knowledge-base/ac-server-software/"
echo "   - Password: CassiaPartners"
echo "   - The file will be named similar to 'Cassia-AC64-2.2.0.xxxxxxxx.zip.gpg'"
echo "2. Open your browser and go to http://$SERVER_IP:8001 to upload the firmware file you just downloaded."
echo "3. Log into the main AC dashboard at http://$SERVER_IP (user: admin, pass: 1q2w#E\$R)."
echo "4. Go to Settings -> Developer Account for RESTful APIs and enter your unique Developer Key and Secret. Save."
echo "5. Go to Settings -> Gateway Auto-Selection, check 'Enable', and click 'Save Setting'."
echo "6. Go to Settings -> AC Web Security, set 'Access Control Allow Origin' to '*', and click 'Save Setting'."
echo "7. Go to the 'Gateways' page, click 'Discover', and add your gateways to the AC."
echo "8. Ensure the gateways themselves are configured to point to the AC's IP address: $SERVER_IP"

if [ "$USER_WAS_ADDED" = true ]; then
    echo "9. FINALLY: To use 'docker' commands in your terminal without 'sudo', please log out and log back in now."
fi
