# V1.1.3 Release - Final Verification ✅

## Package Location
`CassiaInstallationsMainV1.1.3/`

---

## All Fixes Confirmed in Binary

### 1. ✅ Worker Pool Capacity Increase
**File:** `worker_pool.go`
- Buffer: 500 → 1,000 per partition
- Total: 400 partitions × 1,000 = **400,000 packet capacity**
- Warning: 750/1,000 (75% threshold)

### 2. ✅ RSSI Threshold
**File:** `connection_logic.go` (Line 94)
```go
const RSSI_THRESHOLD = -85
```
- Only connects devices ≥ -85 dBm

### 3. ✅ STRICT 125-Sample ECG Enforcement
**File:** `devicehandlers/decode_belt_handler.go`
- EXACTLY 125 samples per JSON POST
- EXACTLY 1 POST per second
- Overflow protection (no data loss)
- Partial packet splitting for exact count

### 4. ✅ NO Cassia Device Limit
**File:** `connection_logic.go`
- Cassia capacity check REMOVED
- ESP32 still has 3-device limit
- Cassia can connect unlimited devices

### 5. ✅ Config Defaults
**File:** `config.json`
```json
"inactivityTimeoutsSeconds": {
  "ECG_Belt": 7,
  "ECG_Belt_V2": 7
}
```

---

## Package Contents

**Binary:**
- `go-ble-orchestrator` (Linux AMD64, 16.9 MB)

**Config:**
- `config.json` (with optimized defaults)

**Scripts:**
- `DeviceManager_Install.sh`
- `CassiaAC_Install.sh`
- `acDeploy64.sh`

**Docs:**
- `README.md`
- `RELEASE_NOTES.md`

**Optional:**
- `frontend/` (dashboard)
- `Dockerfile` (container deployment)

---

## Deployment Command

```bash
cd CassiaInstallationsMainV1.1.3
chmod +x *.sh
sudo ./DeviceManager_Install.sh
```

---

## Quick Upgrade

```bash
sudo systemctl stop go-ble-orchestrator
sudo cp CassiaInstallationsMainV1.1.3/go-ble-orchestrator /opt/go-ble-orchestrator/
sudo systemctl start go-ble-orchestrator
```

---

**Status:** Ready for production deployment
**Build Date:** 2026-01-12
**Version:** 1.1.3
