# V1.1.3 Deployment Guide - Production Ready

## Release Package: CassiaInstallationsMainV1.1.3

### What's Included ✅

**Binary:**
- `go-ble-orchestrator` - Linux AMD64 binary (16.9 MB)

**Configuration:**
- `config.json` - Production defaults (ECG inactivity: 7s)

**Installation Scripts:**
- `CassiaAC_Install.sh` - Cassia AC setup
- `DeviceManager_Install.sh` - Orchestrator service install
- `acDeploy64.sh` - Quick deployment script

**Frontend:**
- `frontend/` - Dashboard UI (Optional)

**Documentation:**
- `README.md` - Full setup guide
- `RELEASE_NOTES.md` - Version changes

---

## Critical Fixes in V1.1.3

### 1. Worker Pool Capacity (4x Increase)
```
Before: 200,000 packets
After:  400,000 packets
```

### 2. RSSI Threshold (Stronger Signals Only)
```
Before: -100 dBm
After:  -85 dBm
```

### 3. ECG Sample Count (STRICT Enforcement)
```
Before: Variable (125-500 samples)
After:  EXACTLY 125 samples per POST
```

### 4. Cassia Capacity Limit
```
Before: Unlimited (router crashes)
After:  2 devices per E1000
```

---

## Config.json Defaults

```json
{
  "inactivityTimeoutsSeconds": {
    "ECG_Belt": 7,        ✅ 7 seconds (default)
    "ECG_Belt_V2": 7,     ✅ 7 seconds (default)
    "ER1": 10,
    "LEPU_BELT": 10,
    "default": 60
  }
}
```

**No changes needed - already optimized!**

---

## Deployment Steps

### Fresh Install:
```bash
cd CassiaInstallationsMainV1.1.3
chmod +x *.sh
sudo ./DeviceManager_Install.sh
sudo systemctl start go-ble-orchestrator
sudo systemctl enable go-ble-orchestrator
```

### Upgrade from V1.1.2:
```bash
sudo systemctl stop go-ble-orchestrator
sudo cp CassiaInstallationsMainV1.1.3/go-ble-orchestrator /opt/go-ble-orchestrator/
sudo systemctl start go-ble-orchestrator
```

**No config changes needed - uses existing `/opt/go-ble-orchestrator/config.json`**

---

## Post-Deployment Verification

### 1. Service Status
```bash
sudo systemctl status go-ble-orchestrator
```
Expected: `Active: active (running)`

### 2. Check Logs
```bash
journalctl -u go-ble-orchestrator.service -f
```

**Expected Logs:**
```
✅ Worker pool started with 400 partitions
✅ All managers initialized
✅ MQTT client connected
```

### 3. Verify 125-Sample Enforcement
```bash
journalctl -u go-ble-orchestrator.service -f | grep "samples"
```
Expected: All JSON POSTs show 125 samples

### 4. Monitor Performance
```bash
journalctl -u go-ble-orchestrator.service -f | grep -E "SLOW|OVERFLOW"
```
Expected: No warnings (or very rare)

---

## Success Criteria

✅ **System is healthy if:**
1. No "SLOW WORKER POOL" warnings
2. Every ECG POST has exactly 125 samples
3. Evaluation time < 1 second
4. CPU usage < 5%
5. All devices streaming reliably

---

## Rollback Plan

If issues occur:
```bash
sudo systemctl stop go-ble-orchestrator
sudo cp CassiaInstalationsMainV1.1.2/go-ble-orchestrator /opt/go-ble-orchestrator/
sudo systemctl start go-ble-orchestrator
```

---

## Support Contact

**Built:** 2026-01-12  
**Version:** 1.1.3  
**Platform:** Linux AMD64  
**Go Version:** 1.21+

🚀 **Ready for Production Deployment!**
