# Cassia Orchestrator & Access Controller Installation Guide

This repository contains the necessary scripts and files to deploy the Cassia Access Controller (AC) and the Go-based BLE Device Manager (Orchestrator) on a Linux system (Ubuntu 22.04 recommended).

## Contents

-   **Access Controller (AC)**: Manages Cassia Gateways.
-   **Device Manager (Orchestrator)**: The main application handling BLE logic.

---

## Part 1: Installing Cassia AC (Optional)

If you need to install the Cassia Access Controller locally using Docker:

1.  **Run the Installer**:
    This script installs Docker, prepares the environment, and pulls the AC container.
    ```bash
    chmod +x CassiaAC_Install.sh
    sudo ./CassiaAC_Install.sh
    ```

2.  **Follow On-Screen Instructions**:
    The script will check for prerequisites and guide you through post-installation steps (e.g., uploading firmware at port 8001).

---

## Part 2: Installing Device Manager

You can run the Device Manager either directly as a **System Service** or via **Docker**.

### Option A: Install as System Service (Recommended for Bare Metal)

This sets up `go-ble-orchestrator` as a systemd service (`/etc/systemd/system/go-ble-orchestrator.service`).

1.  **Install**:
    ```bash
    chmod +x DeviceManager_Install.sh
    sudo ./DeviceManager_Install.sh
    ```
    *This copies the binary and config to `/opt/go-ble-orchestrator` and starts the service.*

2.  **Manage Service**:
    ```bash
    sudo systemctl status go-ble-orchestrator
    sudo systemctl stop go-ble-orchestrator
    sudo systemctl restart go-ble-orchestrator
    ```

3.  **View Logs**:
    ```bash
    journalctl -u go-ble-orchestrator -f
    ```

### Option B: Run with Docker Compose

Run the application in an isolated container using Docker Compose.

1.  **Prepare Database File**:
    Ensure the DB file exists so Docker mounts it correctly.
    ```bash
    touch unified_orchestrator.db
    ```

2.  **Start Container**:
    ```bash
    docker-compose up -d --build
    ```

3.  **View Logs**:
    ```bash
    docker-compose logs -f
    ```

4.  **Stop**:
    ```bash
    docker-compose down
    ```

### Option C: Run on Windows (Local Development)

To run the application natively on Windows:

1.  **Run the Installer Script**:
    Double-click the `DeviceManager_Run_Windows.bat` file.
    *(This script ensures the database file exists and starts the `go-ble-orchestrator.exe` binary)*

2.  **Verify**:
    A console window will open showing the application logs.
    Keep this window open to keep the application running.


---

## Accessing the Live Database (Remote/Tailscale)

The database (`unified_orchestrator.db`) is locked by the application and owned by `root`. To view it on your local machine (e.g., Windows), follow these steps to download a copy.

### Step 1: Prepare the File (On Linux)
Run these commands in your Linux terminal to make a readable copy in your home directory:

```bash
# 1. Make a copy of the active database
sudo cp /opt/go-ble-orchestrator/unified_orchestrator.db ~/db_copy.db

# 2. Fix permissions so you can download it
sudo chown $(whoami):$(whoami) ~/db_copy.db
```

### Step 2: Download the File (On Windows/Local)
Run this command in **PowerShell** on your local machine.
*(Replace `linux_user` with your username and `100.x.y.z` with your Linux Tailscale IP)*

```powershell
scp linux_user@100.x.y.z:~/db_copy.db .
```

### Step 3: View the Data
Open `db_copy.db` using **[DB Browser for SQLite](https://sqlitebrowser.org/)**.


## Uninstallation

To remove components:

-   **Remove Device Manager (System Service)**:
    ```bash
    sudo ./DeviceManager_Uninstall.sh
    ```

-   **Remove Cassia AC**:
    ```bash
    sudo ./CassiaAC_Uninstall.sh
    ```
