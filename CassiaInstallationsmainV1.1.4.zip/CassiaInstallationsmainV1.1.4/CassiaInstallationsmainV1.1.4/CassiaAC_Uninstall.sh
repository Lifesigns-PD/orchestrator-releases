#!/bin/bash

# This script removes the Cassia AC container, its Docker image,
# the downloaded firmware file, and the deployment script.

# --- Check if Docker is running ---
echo "--- Checking if Docker daemon is running... ---"
if ! sudo docker info > /dev/null 2>&1; then
    echo "--- ERROR: Docker daemon is not running. Please start Docker and re-run this script. ---"
    exit 1
fi
echo "--- Docker daemon is running. ---"
echo ""

# --- Configuration ---
FIRMWARE_FILE="Cassia-AC64-latest.zip.gpg"
DEPLOY_SCRIPT="acDeploy64.sh"
# --- End of Configuration ---


echo "--- Stopping and removing the Cassia AC container (ac64)... ---"
sudo docker stop ac64 > /dev/null 2>&1 || true
sudo docker rm ac64 > /dev/null 2>&1 || true
echo "--- Container stopped and removed. ---"

echo ""
echo "--- Removing the Cassia updater Docker image... ---"
sudo docker image rm cassia/updater64 > /dev/null 2>&1 || true
echo "--- Docker image removed. ---"

echo ""
echo "--- Removing downloaded firmware file... ---"
rm -f "$FIRMWARE_FILE" || true
echo "--- Firmware file removed. ---"

echo ""
echo "--- Removing deployment script... ---"
rm -f "$DEPLOY_SCRIPT" || true
echo "--- Deployment script removed. ---"

echo ""
echo "✅ All Cassia-specific components have been uninstalled."
