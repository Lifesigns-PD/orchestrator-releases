#!/bin/bash

# Define variables
SERVICE_NAME="go-ble-orchestrator"
INSTALL_DIR="/opt/go-ble-orchestrator"
SERVICE_FILE="/etc/systemd/system/${SERVICE_NAME}.service"
BINARY_NAME="go-ble-orchestrator"


# Check if running as root
if [ "$EUID" -ne 0 ]; then
  echo "Please run as root"
  exit 1
fi

echo "--- Step 1: Mosquitto MQTT Broker Setup ---"

# 1. Install Mosquitto if not present
if ! command -v mosquitto &> /dev/null; then
    echo "Mosquitto not found. Installing..."
    apt-get update
    apt-get install -y mosquitto mosquitto-clients
    systemctl enable mosquitto
else
    echo "Mosquitto is already installed."
fi

# 2. Configure Mosquitto (Listener 1883, Allow Anonymous)
# We overwrite the main config to ensure it works, as default configs often block remote access.
CONF_FILE="/etc/mosquitto/mosquitto.conf"

echo "Configuring Mosquitto to listen on port 1883 (Anonymous)..."

# Backup existing config if it exists and isn't our backup
if [ -f "${CONF_FILE}" ] && [ ! -f "${CONF_FILE}.bak" ]; then
    cp ${CONF_FILE} ${CONF_FILE}.bak
    echo "Backed up original config to ${CONF_FILE}.bak"
fi

# Write a complete, known-good configuration
cat <<EOF > ${CONF_FILE}
# Unified BLE Orchestrator - Auto Generated Config
pid_file /run/mosquitto/mosquitto.pid
persistence true
persistence_location /var/lib/mosquitto/
log_dest file /var/log/mosquitto/mosquitto.log

# Port 1883 for MQTT
listener 1883
allow_anonymous true
EOF

# Ensure log directory permissions
mkdir -p /var/log/mosquitto
chown -R mosquitto:mosquitto /var/log/mosquitto
chmod 755 /var/log/mosquitto

# Ensure data directory permissions
mkdir -p /var/lib/mosquitto
chown -R mosquitto:mosquitto /var/lib/mosquitto
chmod 755 /var/lib/mosquitto

# 3. Restart Mosquitto to apply changes
echo "Restarting Mosquitto service..."
systemctl stop mosquitto
sleep 1
systemctl start mosquitto

# Wait a moment for it to come up
sleep 2

# Check if it's running
if systemctl is-active --quiet mosquitto; then
    echo "Mosquitto is running successfully."
else
    echo "ERROR: Mosquitto service failed to start."
    echo "Check logs with: journalctl -u mosquitto -n 20"
fi

echo "--- Step 2: Installing ${SERVICE_NAME} ---"

# Stop service if running
if systemctl is-active --quiet ${SERVICE_NAME}; then
    echo "Stopping existing service..."
    systemctl stop ${SERVICE_NAME}
fi

# Create installation directory
echo "Creating directory ${INSTALL_DIR}..."
mkdir -p ${INSTALL_DIR}

# Copy files
echo "Copying files..."
if [ -f "./${BINARY_NAME}" ]; then
    cp ./${BINARY_NAME} ${INSTALL_DIR}/
else
    echo "Error: Binary ${BINARY_NAME} not found in current directory."
    exit 1
fi

if [ -f "./config.json" ]; then
    cp ./config.json ${INSTALL_DIR}/
else
    echo "Warning: config.json not found in current directory. Please ensure it is present in ${INSTALL_DIR} for the app to run."
fi

if [ -d "./frontend" ]; then
    cp -r ./frontend ${INSTALL_DIR}/
else
    echo "Warning: frontend directory not found. Web interface may not work."
fi

# Set permissions
chmod +x ${INSTALL_DIR}/${BINARY_NAME}

# Create systemd service file
echo "Creating systemd service file..."
cat <<EOF > ${SERVICE_FILE}
[Unit]
Description=Go BLE Orchestrator Service
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=${INSTALL_DIR}
ExecStart=${INSTALL_DIR}/${BINARY_NAME}
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal
SyslogIdentifier=${SERVICE_NAME}

[Install]
WantedBy=multi-user.target
EOF

# Reload systemd and enable service
echo "Reloading systemd daemon..."
systemctl daemon-reload

echo "Enabling and starting service..."
systemctl enable ${SERVICE_NAME}
systemctl start ${SERVICE_NAME}

echo "${SERVICE_NAME} installed and started successfully."
echo "Check status with: systemctl status ${SERVICE_NAME}"
echo "To view logs: journalctl -u ${SERVICE_NAME} -f"
